"""
Wagtail Subscriptions - Comprehensive subscription management for Wagtail CMS
"""

__version__ = "1.0.0"
__author__ = "Wagtail Subscriptions Team"

default_app_config = "wagtail_subscriptions.apps.WagtailSubscriptionsConfig"